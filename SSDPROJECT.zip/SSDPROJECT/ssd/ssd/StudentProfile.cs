﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;
namespace ssd
{
    public partial class StudentProfile : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");

        public StudentProfile()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StudentPanel s = new StudentPanel();
            s.Show();
            this.Hide();
        }

        private void StudentProfile_Load(object sender, EventArgs e)
        {
            con.Open();
            String query = "select * from StudentsDetails where SSDID = '"
                                + StudentLoginPage.uid + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox1.Text = dr["Sname"].ToString();
                textBox2.Text = dr["Dept"].ToString();
                textBox3.Text = dr["Yr"].ToString();
                textBox4.Text = dr["Sem"].ToString();
                textBox5.Text = dr["Mobile"].ToString();
                textBox8.Text = dr["EmailID"].ToString();
                textBox6.Text = dr["Password"].ToString();
            }
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox8.Text = "";
                textBox7.Text = "";
                textBox6.Text = "";

                MessageBox.Show("No Record Found !");
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //con.Open();
            //OleDbCommand cmd = con.CreateCommand();
            //cmd.CommandType = CommandType.Text;
            //cmd.CommandText = "update StudentsDetails set Sname = '"
            //                    + textBox1.Text
            //                    + "', Dept = '"
            //                    + textBox2.Text
            //                    + "', Yr = '"
            //                    + textBox3.Text
            //                    + "', Sem = '"
            //                    + textBox4.Text
            //                    + "', Mobile = '"
            //                    + textBox5.Text
            //                    + "', EmailID = '"
            //                    + textBox8.Text
            //                    + "', Password = '"
            //                    + textBox6.Text
            //                    + "' where SSDID = '"
            //                    + textBox7.Text + "'";
            //cmd.ExecuteNonQuery();
            //con.Close();


            //delete
            con.Open();
            OleDbCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "delete from StudentsDetails where SSDID = '"
                                + textBox7.Text + "'";
            cmd1.ExecuteNonQuery();
            con.Close();


            //add
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into StudentsDetails values('"
                                + textBox1.Text + "','"
                                + textBox2.Text + "','"
                                + textBox3.Text + "','"
                                + textBox4.Text + "','"
                                + textBox5.Text + "','"
                                + textBox8.Text + "','"
                                + textBox7.Text + "','"
                                + textBox6.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("1 record updated");
        }
    }
}
