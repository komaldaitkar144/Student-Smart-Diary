﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


using System.Data.OleDb;
namespace ssd
{
    public partial class Result : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");

        public Result()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdminPanel a1 = new AdminPanel();
            a1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AViewResult a = new AViewResult();
            a.Show();
            this.Hide();
        }





        private void Result_Load(object sender, EventArgs e)
        {

        }

       

        private void button5_Click(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            // fetch in combo
            con.Open();
            String query = "select * from StudentsDetails where Dept = '" + comboBox4.Text + "' and Yr = '" + comboBox1.Text + "' and Sem='" + comboBox2.Text + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr["Sname"].ToString());
                //  textBox3.Text = dr["Address"].ToString();
            }

            con.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into RESULT values('"
                                + comboBox4.Text + "','"
                                + comboBox1.Text + "','"
                                + comboBox2.Text + "','"
                                + comboBox3.Text + "','"
                                + comboBox5.Text + "','"
                                + textBox1.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("1 record inserted");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("I");
                comboBox2.Items.Add("II");
            }
            if (comboBox1.SelectedIndex == 1)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("III");
                comboBox2.Items.Add("IV");
            }

            if (comboBox1.SelectedIndex == 2)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("V");
                comboBox2.Items.Add("VI");
            }
        }
    }
}
