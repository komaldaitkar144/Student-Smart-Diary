﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;
namespace ssd
{
    public partial class PTimeTable : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");

        public PTimeTable()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ParentPanel p = new ParentPanel();
            p.Show();
            this.Hide();

        }

   
        private void PTimeTable_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("I");
                comboBox2.Items.Add("II");
            }
            if (comboBox1.SelectedIndex == 1)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("III");
                comboBox2.Items.Add("IV");
            }

            if (comboBox1.SelectedIndex == 2)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("V");
                comboBox2.Items.Add("VI");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            String query = "select * from TimeTable where BARNCH = '" + comboBox4.Text + "' and YR = '" + comboBox1.Text + "' and SEM='" + comboBox2.Text + "' and BATCH ='" + comboBox3.Text + "'";

            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                //textBox1.Text = dr["Sname"].ToString();
                //textBox2.Text = dr["Dept"].ToString();
                //textBox3.Text = dr["Yr"].ToString();
                //textBox4.Text = dr["Sem"].ToString();
                //textBox5.Text = dr["Mobile"].ToString();
                //textBox8.Text = dr["EmailID"].ToString();
                //textBox6.Text = dr["Password"].ToString();
                textBox1.Text = dr["M1"].ToString();
                textBox6.Text = dr["M2"].ToString();
                textBox11.Text = dr["M3"].ToString();
                textBox12.Text = dr["M4"].ToString();
                textBox21.Text = dr["M5"].ToString();
                textBox23.Text = dr["M6"].ToString();
                textBox22.Text = dr["M7"].ToString();
                textBox24.Text = dr["M8"].ToString();
                textBox41.Text = dr["M9"].ToString();
                textBox2.Text = dr["T1"].ToString();
                textBox8.Text = dr["T2"].ToString();
                textBox15.Text = dr["T3"].ToString();
                textBox16.Text = dr["T4"].ToString();
                textBox29.Text = dr["T5"].ToString();
                textBox31.Text = dr["T6"].ToString();
                textBox30.Text = dr["T7"].ToString();
                textBox32.Text = dr["T8"].ToString();
                textBox43.Text = dr["T9"].ToString();
                textBox3.Text = dr["W1"].ToString();
                textBox7.Text = dr["W2"].ToString();
                textBox13.Text = dr["W3"].ToString();
                textBox14.Text = dr["W4"].ToString();
                textBox25.Text = dr["W5"].ToString();
                textBox27.Text = dr["W6"].ToString();
                textBox26.Text = dr["W7"].ToString();
                textBox28.Text = dr["W8"].ToString();
                textBox42.Text = dr["W9"].ToString();
                textBox4.Text = dr["TH1"].ToString();
                textBox9.Text = dr["TH2"].ToString();
                textBox17.Text = dr["TH3"].ToString();
                textBox18.Text = dr["TH4"].ToString();
                textBox33.Text = dr["TH5"].ToString();
                textBox35.Text = dr["TH6"].ToString();
                textBox34.Text = dr["TH7"].ToString();
                textBox36.Text = dr["TH8"].ToString();
                textBox44.Text = dr["TH9"].ToString();
                textBox5.Text = dr["F1"].ToString();
                textBox10.Text = dr["F2"].ToString();
                textBox19.Text = dr["F3"].ToString();
                textBox20.Text = dr["F4"].ToString();
                textBox37.Text = dr["F5"].ToString();
                textBox39.Text = dr["F6"].ToString();
                textBox38.Text = dr["F7"].ToString();
                textBox40.Text = dr["F8"].ToString();
                textBox45.Text = dr["F9"].ToString();
                // comboBox4.Text   =dr["BRANCH"].ToString();
                //comboBox1.Text =dr["YR"].ToString();
                //comboBox2.Text = dr["SEM"].ToString();

                //comboBox3.Text = dr["BATCH"].ToString();

            }
            else
            {
                textBox1.Text = "";
                textBox6.Text = "";
                textBox11.Text = "";
                textBox12.Text = "";
                textBox21.Text = "";
                textBox23.Text = "";
                textBox22.Text = "";
                textBox24.Text = "";
                textBox41.Text = "";

                textBox2.Text = "";
                textBox7.Text = "";
                textBox15.Text = "";
                textBox16.Text = "";
                textBox29.Text = "";
                textBox31.Text = "";
                textBox30.Text = "";
                textBox32.Text = "";
                textBox43.Text = "";

                textBox3.Text = "";
                textBox8.Text = "";
                textBox13.Text = "";
                textBox14.Text = "";
                textBox25.Text = "";
                textBox27.Text = "";
                textBox26.Text = "";
                textBox28.Text = "";
                textBox42.Text = "";

                textBox4.Text = "";
                textBox9.Text = "";
                textBox17.Text = "";
                textBox18.Text = "";
                textBox33.Text = "";
                textBox35.Text = "";
                textBox34.Text = "";
                textBox36.Text = "";
                textBox44.Text = "";

                textBox5.Text = "";
                textBox10.Text = "";
                textBox19.Text = "";
                textBox20.Text = "";
                textBox37.Text = "";
                textBox39.Text = "";
                textBox38.Text = "";
                textBox40.Text = "";
                textBox45.Text = "";

                MessageBox.Show("No Record Found !");
            }
            con.Close();
        }
    }
}
