﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;
namespace ssd
{
    public partial class AViewResult : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");

        public AViewResult()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Result r = new Result();
            r.Show();
            this.Hide();
        }

        private void AViewResult_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("I");
                comboBox2.Items.Add("II");
            }
            if (comboBox1.SelectedIndex == 1)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("III");
                comboBox2.Items.Add("IV");
            }

            if (comboBox1.SelectedIndex == 2)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("V");
                comboBox2.Items.Add("VI");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            // fetch in combo
            con.Open();
            String query = "select * from StudentsDetails where Dept = '" + comboBox4.Text + "' and Yr = '" + comboBox1.Text + "' and Sem='" + comboBox2.Text + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr["Sname"].ToString());
                //  textBox3.Text = dr["Address"].ToString();
            }

            con.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from RESULT where BRANCH ='"
                + comboBox4.Text + "' and YR = '"
                + comboBox1.Text + "' and SEM='"
                + comboBox2.Text + "' AND SNAME='" + comboBox3.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        
    }
}
