﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;


namespace ssd
{
    public partial class AddParent : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");
        public AddParent()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {


        }

        private void AddParent_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminPanel a1 = new AdminPanel();
            a1.Show();
            this.Hide();
        }
        public void clr()
        {
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox8.Text = "";
            textBox7.Text = "";
            textBox6.Text = "";

        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into ParentDetails values('"
                                + textBox3.Text + "','"
                                + textBox4.Text + "','"
                                + textBox5.Text + "','"
                                + textBox8.Text + "','"
                                + textBox7.Text + "','"
                                + textBox6.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("1 record inserted");
            clr();
            //          display();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //con.Open();
            //OleDbCommand cmd = con.CreateCommand();
            //cmd.CommandType = CommandType.Text;
            //cmd.CommandText = "update ParentDetails set Pname = '"
            //                    + textBox3.Text
            //                    + "', Sname = '"
            //                    + textBox4.Text 
            //                    + "', Mobile = '"
            //                    + textBox5.Text 
            //                    + "', EmailID = '"
            //                    + textBox8.Text 
            //                    + "', Password = '"
            //                    + textBox6.Text 
            //                    + "' where SSDID = '"
            //                    + textBox7.Text + "'";
            //cmd.ExecuteNonQuery();
            //con.Close();

            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from ParentDetails where SSDID = '"
                                + textBox7.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();

            //add new
            con.Open();
            OleDbCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "Insert into ParentDetails values('"
                                + textBox3.Text + "','"
                                + textBox4.Text + "','"
                                + textBox5.Text + "','"
                                + textBox8.Text + "','"
                                + textBox7.Text + "','"
                                + textBox6.Text + "')";
            cmd1.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("1 record updated");
            clr();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            String query = "select * from ParentDetails where SSDID = '"
                                + textBox7.Text + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox3.Text = dr["Pname"].ToString();
                textBox4.Text = dr["Sname"].ToString();
                textBox5.Text = dr["Mobile"].ToString();
                textBox8.Text = dr["EmailID"].ToString();
                textBox6.Text = dr["Password"].ToString();
            }
            else
            {
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox8.Text = "";
                textBox7.Text = "";
                textBox6.Text = "";

                MessageBox.Show("No Record Found !");
            }
            con.Close();
        }
    }
}
