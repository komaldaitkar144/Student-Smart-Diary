﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;

namespace ssd
{
    public partial class SSD___Enotice : Form
    {
        public SSD___Enotice()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(textBox2.Text);
                mail.From = new MailAddress("farmh125@gmail.com");
                mail.Subject = "GPT Notice !! Imporatant Notice...";
                string Body = "Important Notice :-" + textBox3.Text +','+textBox4.Text+"\n Please Do not reply this email. ";
                mail.Body = Body;
                if (labelpath.Text.Length > 0)
                {
                    if (System.IO.File.Exists(labelpath.Text))
                    {
                        mail.Attachments.Add(new Attachment(labelpath.Text));

                    }
                }
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential("farmh125@gmail.com", "final_project");

                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);
                MessageBox.Show("otp has been sent to\n" + textBox2.Text);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Incorrect Email Id");
            }

            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(textBox5.Text);
                mail.From = new MailAddress("farmh125@gmail.com");
                mail.Subject = "GPT Notice !!";
                string Body = "Important Notice :- " + textBox4.Text + "\n Please Do not reply this email. ";
                mail.Body = Body;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential("farmh125@gmail.com", "final_project");

                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);
                MessageBox.Show("otp has been sent to" + textBox5.Text);
                textBox2.Text = "";
                textBox5.Text = "";
            }
            catch (Exception ex)
            {
                
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                labelpath.Text = openFileDialog1.FileName;
                linkLabel1.Visible = false;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            TeacherPanel tp = new TeacherPanel();
            tp.Show();
            this.Hide();
        }
    }
}
