﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;
namespace ssd
{
    public partial class ViewNotice : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");

        public ViewNotice()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ViewNoticeList v = new ViewNoticeList();
            v.Show();
            this.Hide();
        }

     

        private void ViewNotice_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            con.Open();
            String query = "select * from NOTICE where TITLE = '"
                                + textBox1.Text + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox7.Text = dr["VENUE"].ToString();
                textBox3.Text = dr["NDATE"].ToString();
                textBox4.Text = dr["NTIME"].ToString();
                textBox5.Text = dr["SUBJECT"].ToString();
                textBox8.Text = dr["DESC"].ToString();

            }
            else
            {
                textBox7.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox8.Text = "";

                MessageBox.Show("No Record Found !");
            }
            con.Close();

        }


    }
}
