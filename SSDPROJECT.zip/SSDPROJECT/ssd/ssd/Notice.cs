﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;
namespace ssd
{
    public partial class Notice : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");
        public Notice()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminPanel a = new AdminPanel();
            a.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AViewNoticeList n = new AViewNoticeList();
            n.Show();
            this.Hide();
        }


        
   

        private void Notice_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into NOTICE values('"
                                + textBox1.Text + "','"
                                + textBox7.Text + "','"
                                + textBox3.Text + "','"
                                + textBox4.Text + "','"
                                + textBox5.Text + "','"
                                + textBox8.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("1 record inserted");

        }

        private void button7_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE FROM NOTICE where TITLE = '"
                                + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            //**********

            con.Open();
            OleDbCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "Insert into NOTICE values('"
                                + textBox1.Text + "','"
                                + textBox7.Text + "','"
                                + textBox3.Text + "','"
                                + textBox4.Text + "','"
                                + textBox5.Text + "','"
                                + textBox8.Text + "')";
            cmd1.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("1 Record is Update..");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            String query = "select * from NOTICE where TITLE = '"
                                + textBox1.Text + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox7.Text = dr["VENUE"].ToString();
                textBox3.Text = dr["NDATE"].ToString();
                textBox4.Text = dr["NTIME"].ToString();
                textBox5.Text = dr["SUBJECT"].ToString();
                textBox8.Text = dr["DESC"].ToString();

            }
            else
            {
                textBox7.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox8.Text = "";

                MessageBox.Show("No Record Found !");
            }
            con.Close();
        }
    }
}
