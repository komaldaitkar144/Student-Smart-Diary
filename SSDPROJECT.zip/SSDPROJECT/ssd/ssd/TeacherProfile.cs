﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;
namespace ssd
{
    public partial class TeacherProfile : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");

        public TeacherProfile()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TeacherPanel t = new TeacherPanel();
            t.Show();
            this.Hide();
        }

        private void TeacherProfile_Load(object sender, EventArgs e)
        {
            con.Open();
            String query = "select * from TeacherDetails where SSDID = '"
                                + TeacherLoginPage.uid + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox1.Text = dr["Tname"].ToString();
                textBox2.Text = dr["Dept"].ToString();

                textBox3.Text = dr["Qualification"].ToString();
                textBox5.Text = dr["Password"].ToString();
            }
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                MessageBox.Show("No Record Found !");
            }
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            //delete 
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from TeacherDetails where SSDID = '"
                                + textBox4.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();

            //add new
            con.Open();
            OleDbCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "Insert into TeacherDetails values('"
                                + textBox1.Text + "','"
                                + textBox2.Text + "','"
                                + textBox3.Text + "','"
                                + textBox4.Text + "','"
                                + textBox5.Text + "')";
            cmd1.ExecuteNonQuery();
            con.Close();
            MessageBox.Show(" 1 record Updated");

        }
    }
}
