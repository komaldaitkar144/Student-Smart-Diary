﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;

namespace ssd
{
    public partial class AdminProfile : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");

        public AdminProfile()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //db updae

            //con.Open();
            //OleDbCommand cmd = con.CreateCommand();
            //cmd.CommandType = CommandType.Text;
            //cmd.CommandText = "update AdminDetails set Password ='"+textBox2.Text+"' where AdminID = '"+ textBox1.Text + "'";
            //cmd.ExecuteNonQuery();
            //con.Close();

            //delete 
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from AdminDetails where AdminID = '"
                                + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();

            //add new
            con.Open();
            OleDbCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "Insert into AdminDetails values('"
                                + textBox1.Text + "','"
                                + textBox2.Text + "')";
            cmd1.ExecuteNonQuery();
            con.Close();
            // navigate
            MessageBox.Show("Admin Id Password Updated");
            Form1 a1 = new Form1();
            a1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminPanel a1 = new AdminPanel();
            a1.Show();
            this.Hide();
        }

        private void AdminProfile_Load(object sender, EventArgs e)
        {
            // fetch values from db
            //db
            con.Open();
            String query = "select * from AdminDetails where AdminID = '"
                                + AdminLoginPage.uid + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox1.Text = dr["AdminID"].ToString();

                textBox2.Text = dr["Password"].ToString();
            }
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                //  textBox3.Text = "";
                MessageBox.Show("No Record Found !");
            }
            con.Close();

        }
    }
}
