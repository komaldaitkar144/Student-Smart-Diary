﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ssd
{
    public partial class ParentPanel : Form
    {
        public ParentPanel()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            ParentProfile p = new ParentProfile();
            p.Show();
            this.Hide();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            PNotice p = new PNotice();
            p.Show();
            this.Hide();
        
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            PTimeTable p = new PTimeTable();
            p.Show();
            this.Hide();
        
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            PAttendance p = new PAttendance();
            p.Show();
            this.Hide();
        
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            PResult p = new PResult();
            p.Show();
            this.Hide();
        
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            Form1 p = new Form1();
            p.Show();
            this.Hide();
        
        }

        private void ParentPanel_Load(object sender, EventArgs e)
        {

        }
    }
}
