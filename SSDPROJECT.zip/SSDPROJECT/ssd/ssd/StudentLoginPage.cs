﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ssd
{
    public partial class StudentLoginPage : Form
    {
        public static String uid = "";
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");
     
        public StudentLoginPage()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String i, p;
            i = p = "prasad";
            //db
            con.Open();
            String query = "select * from StudentsDetails where SSDID = '"
                                + textBox1.Text + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                i = dr["SSDID"].ToString();
                uid = i;
                p = dr["Password"].ToString();
            }
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                //  textBox3.Text = "";
                MessageBox.Show("No Record Found !");
            }
            con.Close();


            if (i == textBox1.Text && p == textBox2.Text)
            {
                //nevigate
                StudentPanel sp = new StudentPanel();
                sp.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid id or pass");
            }
        }

        private void StudentLoginPage_Load(object sender, EventArgs e)
        {

        }
    }
}
