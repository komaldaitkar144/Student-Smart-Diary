﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.OleDb;

namespace ssd
{
    public partial class Attendance : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\kOMAL Project\SSDPROJECT\MyDB.mdb");

        public Attendance()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdminPanel a1 = new AdminPanel();
            a1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ViewAttendance v = new ViewAttendance();
            v.Show();
            this.Hide();
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Attendance_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("I");
                comboBox2.Items.Add("II");
            }
            if (comboBox1.SelectedIndex == 1)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("III");
                comboBox2.Items.Add("IV");
            }

            if (comboBox1.SelectedIndex == 2)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("V");
                comboBox2.Items.Add("VI");
            }
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            //412315
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into ATTENDANCE values('"
                                + comboBox4.Text + "','"
                                + comboBox1.Text + "','"
                                + comboBox2.Text + "','"
                                + comboBox3.Text + "','"
                                + textBox1.Text + "','"
                                + comboBox5.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("1 record inserted");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            // fetch in combo
            con.Open();
            String query = "select * from StudentsDetails where Dept = '" + comboBox4.Text + "' and Yr = '" + comboBox1.Text + "' and Sem='" + comboBox2.Text + "'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr["Sname"].ToString());
                //  textBox3.Text = dr["Address"].ToString();
            }

            con.Close();
        }
    }
}
