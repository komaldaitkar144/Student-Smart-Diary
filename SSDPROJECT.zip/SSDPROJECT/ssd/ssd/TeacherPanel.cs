﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ssd
{
    public partial class TeacherPanel : Form
    {
        public TeacherPanel()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            TeacherProfile t = new TeacherProfile();
            t.Show();
            this.Hide();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            ViewNoticeList v = new ViewNoticeList();
            v.Show();
            this.Hide();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            ViewTimeTablePage v = new ViewTimeTablePage();
            v.Show();
            this.Hide();

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            TAttendance v = new TAttendance();
            v.Show();
            this.Hide();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            TResult t = new TResult();
            t.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            SSD___Enotice en = new SSD___Enotice();
            en.Show();
            this.Hide();
        }
    }
}
